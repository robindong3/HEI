import pytest
from simplemaths.simplemaths import SimpleMaths as sm

class TestSimpleMaths():
    pass
